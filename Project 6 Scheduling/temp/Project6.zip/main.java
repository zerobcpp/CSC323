
/*
 * Project 6:  Scheduling
 * LinBo Zhang
 */
import java.io.*;
import java.util.Arrays;
import java.util.Scanner;

public class main {
	public static void main(String args[]) throws Exception {
		Schedule test = new Schedule();
		File set_11 = new File(args[0]); // input1
		File set_12 = new File(args[1]); // input2
		File out_1 = new File(args[0].replaceAll(".txt", "output.txt"));
		File out_2 = new File(args[1].replaceAll(".txt", "output.txt"));
		out_1.createNewFile();
		out_2.createNewFile();
		FileWriter out_1writer = new FileWriter(out_1);
		FileWriter out_2writer = new FileWriter(out_2);
		Scanner reader_1 = new Scanner(set_11);
		Scanner reader_2 = new Scanner(set_12);
		int i1, i2;
		i1 = reader_1.nextInt();
		i2 = reader_2.nextInt();
		if (i2 <= 0)
			throw new Exception("Process number must be greater than 1\n");
		else if (i2 > i1)
			i2 = i1;
		int currentTime = 0;
		//int processorUsed = 0;
		test.numNodes = i1;
		test.numProcessor = 4; // Subjected to change.
		try {
			if (args[2] != null) {
				test.numProcessor = Integer.parseInt(args[2]);
			} else if (args[2] == "u") {
				test.numProcessor = i1 + 2;
			}
		} catch (Exception e) {
			System.out.println("Processor Number is not being input in the command, using default processor number\n");
		}
		test.adjMatrix = new int[test.numNodes + 1][test.numNodes + 1];
		test.OPEN = new Node();
		test.loadMatrix(set_11);
		test.loadJobTimeArr(set_12);
		test.setMatrix();
		test.PrintMatrix(out_2writer);
		while (!test.isEmpty()) {
			while (true) {
				int job = test.findOrphan();
				// System.out.println(job);
				if (job > 0) {
					Node n = new Node(job, test.jobTimearr[job]);
					test.OpenInsert(n);
					test.printOPEN(out_2writer);
				} else {
					// System.out.println("Job < 0");
					break;
				}
			}

			int onProcessor = test.getNextProcessor(currentTime);

			while (onProcessor > 0 && test.OPEN.next != null && test.processUsed < test.numProcessor) {
				if (onProcessor > 0) {
					// System.out.println(onProcessor +"\n"+currentTime);
					Node newJob = test.OPEN.next;
					test.OPEN.next = test.OPEN.next.next;
					test.putJobTable(onProcessor, currentTime, newJob.jobID, newJob.jobTime);
//					onProcessor = test.getNextProcessor(currentTime);
					if (onProcessor > test.processUsed)
						test.processUsed += 1;
					onProcessor = test.getNextProcessor(currentTime);
				}
			}
			test.printTable(out_1writer, currentTime);

			if (!test.isCycle())
				throw new Exception("There is a cycle in the graph"
						+ "\nOr there are not enough processor to deal with left over jobs");
			currentTime++;
			int proc = 0;
			while (proc <= test.numProcessor) {
 				if (test.Table[proc][currentTime] <= 0 && test.Table[proc][currentTime - 1] > 0) {
					int jobID = test.Table[proc][currentTime - 1];
					test.deleteJobID(jobID);
				}
				test.PrintMatrix(out_2writer);
				proc++;
			}
		}

		System.out.println("****Debugging Purpose****");
		System.out.println(test.processUsed);
		System.out.println(Arrays.deepToString(test.adjMatrix));
		System.out.println(Arrays.deepToString(test.Table));
		System.out.println(Arrays.toString(test.jobTimearr));
		return;
	}
}